
Tomato - v2 2020-06-11 2:09pm
==============================

This dataset was exported via roboflow.ai on June 11, 2020 at 2:10 AM GMT

It includes 895 images.
Tomato are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


